VisaRoute — prototype initial

Contenu : index.html (site statique avec carte Leaflet/OpenStreetMap).

Pour publier gratuitement via Cloudflare Pages :
1. Crée un compte GitHub et un dépôt public nommé visaroute.
2. Ajoute index.html à la racine du dépôt.
3. Dans Cloudflare Dashboard > Workers & Pages > Create > Pages > Connect to Git.
4. Choisis le dépôt. Framework preset : None. Build command : vide. Build output directory : /.
5. Déploie.

Important : cette version est une maquette fonctionnelle de l’interface. Les réponses de visa ne sont pas encore reliées à des sources officielles, et l’administration sécurisée doit être ajoutée avec un backend (ex. Supabase). Ne pas présenter les résultats comme des conseils officiels.
